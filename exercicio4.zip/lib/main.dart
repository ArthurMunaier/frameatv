
import 'package:flutter/material.dart';

void main() => runApp(const MeuApp());

class MeuApp extends StatelessWidget {
  const MeuApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: const TelaLogin(),
    );
  }
}

class TelaLogin extends StatefulWidget {
  const TelaLogin({super.key});
  @override
  State<TelaLogin> createState() => _TelaLoginState();
}

class _TelaLoginState extends State<TelaLogin> {
  final email = TextEditingController();
  final senha = TextEditingController();
  String msg = "";

  void entrar() {
    setState(() {
      if (email.text.isEmpty) {
        msg = "Digite seu email";
      } else if (!email.text.contains("@")) {
        msg = "Digite um email válido";
      } else if (senha.text.isEmpty) {
        msg = "Digite sua senha";
      } else {
        Navigator.push(context,
            MaterialPageRoute(builder: (_) => const TelaHome()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Login")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          const Icon(Icons.person, size: 80),
          const Text("Login"),
          const Text("Digite seus dados para entrar"),
          TextField(controller: email, decoration: const InputDecoration(labelText: "Email")),
          TextField(controller: senha, obscureText: true, decoration: const InputDecoration(labelText: "Senha")),
          Text(msg, style: const TextStyle(color: Colors.red)),
          ElevatedButton(onPressed: entrar, child: const Text("Entrar")),
          ElevatedButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TelaCadastro())),
            child: const Text("Criar conta"),
          )
        ]),
      ),
    );
  }
}

class TelaCadastro extends StatefulWidget {
  const TelaCadastro({super.key});
  @override
  State<TelaCadastro> createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  final nome = TextEditingController();
  final email = TextEditingController();
  final senha = TextEditingController();
  final confirmar = TextEditingController();
  String msg = "";

  void cadastrar() {
    setState(() {
      if (nome.text.isEmpty) {
        msg = "Digite seu nome";
      } else if (email.text.isEmpty) {
        msg = "Digite seu email";
      } else if (!email.text.contains("@")) {
        msg = "Digite um email válido";
      } else if (senha.text.isEmpty) {
        msg = "Digite sua senha";
      } else if (senha.text.length < 6) {
        msg = "A senha precisa ter pelo menos 6 caracteres";
      } else if (senha.text != confirmar.text) {
        msg = "As senhas não são iguais";
      } else {
        Navigator.push(context, MaterialPageRoute(builder: (_) => const TelaHome()));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Cadastro")),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(children: [
          const Icon(Icons.person_add, size: 80),
          const Text("Criar Conta"),
          TextField(controller: nome, decoration: const InputDecoration(labelText: "Nome")),
          TextField(controller: email, decoration: const InputDecoration(labelText: "Email")),
          TextField(controller: senha, obscureText: true, decoration: const InputDecoration(labelText: "Senha")),
          TextField(controller: confirmar, obscureText: true, decoration: const InputDecoration(labelText: "Confirmar Senha")),
          Text(msg),
          ElevatedButton(onPressed: cadastrar, child: const Text("Cadastrar")),
          ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text("Voltar para Login"))
        ]),
      ),
    );
  }
}

class TelaHome extends StatelessWidget {
  const TelaHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Home")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.home, size: 100),
            const Text("Bem-vindo!"),
            const Text("Login realizado com sucesso."),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Sair"),
            )
          ],
        ),
      ),
    );
  }
}
