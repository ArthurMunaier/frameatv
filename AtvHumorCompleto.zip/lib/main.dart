
import 'package:flutter/material.dart';

void main() {
  runApp(const MoodApp());
}

class MoodApp extends StatelessWidget {
  const MoodApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Mood App',
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Color corHumor = Colors.grey;
  double tamanho = 180;
  IconData icone = Icons.sentiment_neutral;
  String textoHumor = 'Escolha um humor';
  String mensagemExtra = '';
  double opacidade = 0;

  void selecionarHumor(String humor) {
    setState(() {
      opacidade = 1;

      switch (humor) {
        case 'Feliz':
          corHumor = Colors.yellow;
          tamanho = 220;
          icone = Icons.sentiment_very_satisfied;
          textoHumor = 'Hoje estou feliz!';
          mensagemExtra = 'Você escolheu o humor Feliz.\nQue bom ver essa energia positiva!';
          break;

        case 'Calmo':
          corHumor = Colors.blue;
          tamanho = 200;
          icone = Icons.cloud;
          textoHumor = 'Momento de tranquilidade.';
          mensagemExtra = 'Você escolheu o humor Calmo.\nRespire fundo e aproveite.';
          break;

        case 'Animado':
          corHumor = Colors.orange;
          tamanho = 240;
          icone = Icons.bolt;
          textoHumor = 'Energia total!';
          mensagemExtra = 'Você escolheu o humor Animado.\nHora de colocar os planos em ação!';
          break;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mood App'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 20),
              const Text(
                'Escolha um humor e veja a tela mudar com animação!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18),
              ),
              const SizedBox(height: 30),
              AnimatedContainer(
                duration: const Duration(milliseconds: 800),
                width: tamanho,
                height: tamanho,
                decoration: BoxDecoration(
                  color: corHumor,
                  borderRadius: BorderRadius.circular(tamanho / 5),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(icone, size: 70),
                    const SizedBox(height: 10),
                    Text(
                      textoHumor,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 30),
              Wrap(
                spacing: 10,
                children: [
                  ElevatedButton(
                    onPressed: () => selecionarHumor('Feliz'),
                    child: const Text('Feliz'),
                  ),
                  ElevatedButton(
                    onPressed: () => selecionarHumor('Calmo'),
                    child: const Text('Calmo'),
                  ),
                  ElevatedButton(
                    onPressed: () => selecionarHumor('Animado'),
                    child: const Text('Animado'),
                  ),
                ],
              ),
              const SizedBox(height: 30),
              AnimatedOpacity(
                opacity: opacidade,
                duration: const Duration(seconds: 1),
                child: Text(
                  mensagemExtra,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 18),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
